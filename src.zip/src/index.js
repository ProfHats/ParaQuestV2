  import React from 'react';
    import ReactDOM from 'react-dom';
    import ParaQuest from './main';
    import '../node_modules/bootstrap/dist/css/bootstrap.css';
	
	var stats = [
	{
	strength : 5,
    brains: 5,
    charm: 5	
	}
	];//these are the beginning stats
	
	
	   ReactDOM.render(
      <ParaQuest character={stats} />,
      document.getElementById('root')
    );