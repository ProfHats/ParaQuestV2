    import React from 'react';

	var statsBar = React.createClass({
		render : function(){
		console.log(this.props.foo[0].strength);
		return(
		 <td>
		 			
		   Strength: {this.props.foo[0].strength}
		   </td>
		);		
		}
	});
	
	var ParaQuest = React.createClass({
        render: function(){

            return (
			<div>
           <table>
		 <tbody>
		  <tr>
		  <statsBar foo={this.props.character}/>
		   </tr>
		   </tbody>
		   </table>
		   </div>
            );
        }
    });
	
	export default ParaQuest;